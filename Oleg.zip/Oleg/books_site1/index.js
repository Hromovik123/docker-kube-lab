const button = document.querySelector('.burger-button')
const menu = document.querySelector('.burger-menu')

button.addEventListener("click", () => {
   menu.classList.toggle('active')
})